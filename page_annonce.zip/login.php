<?php
//include ( 'L_fonctions_generales.php');
include ('FonctionGAnnonce.php');

setHeaderNoCache();
gestionSession();

$newAnnonce = new Annonce();

if ( isset($_POST['envoi']) )
{
    $newAnnonce->parsePost();
    $newAnnonce->save();

    header ('location: page_annonce.php');
}
echo $newAnnonce->formAnnonce("login.php");

$ret_annonce_array = parsePost();

if ( $ret_annonce_array != NULL )
{
    // j'enregistre l'annonce dans le dictionnaire avec la clé 'compteur' 
    $annonces[ $compteur ] = $ret_annonce_array; 
    // j'enregistre mon dictionnaire d'annonce dans la session
    $_SESSION[ "annonces" ]  = $annonces;
    
    // j'incremente le compteur 
    $compteur++;
    //j'enregistre la valeurs actuelle du compteur dans la session
    $_SESSION[ "compteur" ]  = $compteur;

    header("location: page_annonce.php");
}

$cible= "login.php";

formAnnonce( $cible );





?>
